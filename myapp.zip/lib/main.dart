import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'views/services_page.dart';
import 'views/about_page.dart';
import 'views/contact_page.dart';
import 'views/home_page.dart';
import 'views/chat_page.dart';

void main() {
  runApp(HomeCleaningStatefulApp());
}

class HomeCleaningStatefulApp extends StatefulWidget {
  @override
  State<HomeCleaningStatefulApp> createState() =>
      _HomeCleaningStatefulAppState();
}

class _HomeCleaningStatefulAppState extends State<HomeCleaningStatefulApp> {
  int _selectedIndex = 0;
  bool _isCupertino = false;

  void _onTabTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  void _toggleUI() {
    setState(() {
      _isCupertino = !_isCupertino;
    });
  }

  @override
  Widget build(BuildContext context) {
    final List<Widget> _pages = [
      Column(
        children: [
          Expanded(child: HomePage(imageAsset: 'assets/cleaning.png')),
        ],
      ),
      ServicesPage(),
      AboutPage(),
      ContactPage(),
    ];

    if (_isCupertino) {
      return CupertinoApp(
        title: 'Home Cleaning Service',
        theme: CupertinoThemeData(
          primaryColor: CupertinoColors.activeBlue,
          barBackgroundColor: CupertinoColors.systemGrey6,
        ),
        home: CupertinoTabScaffold(
          tabBar: CupertinoTabBar(
            backgroundColor: CupertinoColors.systemGrey6,
            currentIndex: _selectedIndex,
            onTap: _onTabTapped,
            activeColor: CupertinoColors.activeBlue,
            items: const [
              BottomNavigationBarItem(
                  icon: Icon(CupertinoIcons.home), label: 'Home'),
              BottomNavigationBarItem(
                  icon: Icon(CupertinoIcons.list_bullet), label: 'Services'),
              BottomNavigationBarItem(
                  icon: Icon(CupertinoIcons.info), label: 'About'),
              BottomNavigationBarItem(
                  icon: Icon(CupertinoIcons.phone), label: 'Contact'),
            ],
          ),
          tabBuilder: (context, index) {
            final List<String> cupertinoTitles = [
              'Home Cleaning Service',
              'Services',
              'About Us',
              'Contact Us',
            ];
            return Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [CupertinoColors.systemGrey5, CupertinoColors.white],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: CupertinoPageScaffold(
                navigationBar: CupertinoNavigationBar(
                  backgroundColor:
                      CupertinoColors.systemGrey6.withOpacity(0.95),
                  middle: Text(cupertinoTitles[index],
                      style: TextStyle(fontWeight: FontWeight.bold)),
                  trailing: CupertinoSwitch(
                    value: _isCupertino,
                    onChanged: (val) => _toggleUI(),
                  ),
                  border: Border(
                      bottom: BorderSide(
                          color: CupertinoColors.systemGrey4, width: 0.5)),
                ),
                child: _pages[index],
              ),
            );
          },
        ),
      );
    } else {
      return MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'CrystalClean Services',
        theme: ThemeData(
          primarySwatch: Colors.blue,
          scaffoldBackgroundColor: Colors.grey[100],
        ),
        home: Scaffold(
          extendBodyBehindAppBar: true,
          appBar: AppBar(
            elevation: 8,
            backgroundColor: Colors.teal.withOpacity(0.95),
            title: Text(
              [
                'CrystalClean Services',
                'Our Services',
                'About Us',
                'Contact Us',
              ][_selectedIndex],
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 20,
                letterSpacing: 1.0,
              ),
            ),
            actions: [
              IconButton(
                icon: Icon(Icons.info_outline, color: Colors.white),
                onPressed: () {
                  showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      title: Text('CrystalClean Services'),
                      content: Text(
                          'Professional cleaning services for your home and business.'),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: Text('OK'),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ],
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.vertical(bottom: Radius.circular(24)),
            ),
          ),
          drawer: Drawer(
            child: SafeArea(
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  // Profile card layout with Row (profile picture + name) and Column (details)
                  Container(
                    padding: EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Colors.teal.shade400, Colors.teal.shade600],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.teal.withOpacity(0.3),
                          blurRadius: 8,
                          offset: Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        // Profile Picture
                        Container(
                          width: 60,
                          height: 60,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white, width: 3),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.2),
                                blurRadius: 8,
                                offset: Offset(0, 4),
                              ),
                            ],
                          ),
                          child: CircleAvatar(
                            radius: 28,
                            backgroundColor: Colors.white,
                            backgroundImage: AssetImage('assets/cleaning.png'),
                            child: Icon(
                              Icons.person,
                              color: Colors.teal.shade600,
                              size: 30,
                            ),
                          ),
                        ),
                        SizedBox(width: 16),
                        // Name and Details Column
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'CrystalClean',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                ),
                              ),
                              SizedBox(height: 4),
                              Text(
                                'Premium Cleaning Services',
                                style: TextStyle(
                                  color: Colors.white.withOpacity(0.9),
                                  fontSize: 14,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              SizedBox(height: 8),
                              Row(
                                children: [
                                  Icon(Icons.star,
                                      color: Colors.amber, size: 16),
                                  SizedBox(width: 4),
                                  Text(
                                    '5.0 Rating',
                                    style: TextStyle(
                                      color: Colors.white.withOpacity(0.9),
                                      fontSize: 12,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                  SizedBox(width: 16),
                                  Icon(Icons.verified,
                                      color: Colors.white, size: 16),
                                  SizedBox(width: 4),
                                  Text(
                                    'Certified',
                                    style: TextStyle(
                                      color: Colors.white.withOpacity(0.9),
                                      fontSize: 12,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  ListTile(
                    leading: Icon(Icons.home, color: Colors.teal),
                    title: Text('Home'),
                    onTap: () {
                      Navigator.pop(context);
                      _onTabTapped(0);
                    },
                  ),
                  ListTile(
                    leading: Icon(Icons.cleaning_services, color: Colors.teal),
                    title: Text('Services'),
                    onTap: () {
                      Navigator.pop(context);
                      _onTabTapped(1);
                    },
                  ),
                  ListTile(
                    leading: Icon(Icons.info, color: Colors.teal),
                    title: Text('About'),
                    onTap: () {
                      Navigator.pop(context);
                      _onTabTapped(2);
                    },
                  ),
                  ListTile(
                    leading: Icon(Icons.phone, color: Colors.teal),
                    title: Text('Contact'),
                    onTap: () {
                      Navigator.pop(context);
                      _onTabTapped(3);
                    },
                  ),
                ],
              ),
            ),
          ),
          body: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.teal.shade50, Colors.white],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: _pages[_selectedIndex],
          ),
          bottomNavigationBar: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.teal.withOpacity(0.1),
                  blurRadius: 16,
                  offset: Offset(0, -2),
                ),
              ],
            ),
            child: SafeArea(
              child: Padding(
                padding: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _CustomNavItem(
                      icon: Icons.home,
                      label: 'Home',
                      isSelected: _selectedIndex == 0,
                      onTap: () => _onTabTapped(0),
                    ),
                    _CustomNavItem(
                      icon: Icons.cleaning_services,
                      label: 'Services',
                      isSelected: _selectedIndex == 1,
                      onTap: () => _onTabTapped(1),
                    ),
                    _CustomNavItem(
                      icon: Icons.info,
                      label: 'About',
                      isSelected: _selectedIndex == 2,
                      onTap: () => _onTabTapped(2),
                    ),
                    _CustomNavItem(
                      icon: Icons.phone,
                      label: 'Contact',
                      isSelected: _selectedIndex == 3,
                      onTap: () => _onTabTapped(3),
                    ),
                  ],
                ),
              ),
            ),
          ),
          floatingActionButton: Builder(
            builder: (context) => FloatingActionButton(
              backgroundColor: Colors.teal,
              child: Icon(Icons.chat_bubble_outline, color: Colors.white),
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => ChatPage()),
                );
              },
            ),
          ),
        ),
      );
    }
  }
}

class _CustomNavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool isSelected;
  final VoidCallback onTap;

  const _CustomNavItem({
    required this.icon,
    required this.label,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? Colors.teal.withOpacity(0.1) : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              color: isSelected ? Colors.teal : Colors.grey.shade600,
              size: 24,
            ),
            SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                fontSize: 12,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                color: isSelected ? Colors.teal : Colors.grey.shade600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
