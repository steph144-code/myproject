import 'package:flutter/material.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
// import '../widgets/custom_button.dart'; // uncomment if you actually use it

class Service {
  final String title;
  final String description;
  final String imageAsset;

  const Service({
    required this.title,
    required this.description,
    required this.imageAsset,
  });
}

const List<Service> services = [
  Service(
    title: 'Spruce Regular Cleaning',
    description:
        'Keeps frequently used and accessible areas clean, perfect for maintaining a fresh, organized home or condo.',
    imageAsset: 'assets/regular_cleaning.jpg',
  ),
  Service(
    title: 'Spruce General Cleaning',
    description:
        'Offers a thorough cleaning of your entire space. Ideal for homes and commercial areas that need a full refresh.',
    imageAsset: 'assets/general_cleaning.jpg',
  ),
  Service(
    title: 'Spruce Premium Cleaning',
    description:
        'Top-tier cleaning for homes and businesses, featuring signature Duo Disinfection for a deep, refined clean.',
    imageAsset: 'assets/premium_cleaning.jpg',
  ),
  Service(
    title: 'Post-Construction Cleaning',
    description:
        'Specializes in cleaning newly built or renovated properties. Removes all construction debris and dust.',
    imageAsset: 'assets/post_construction.jpg',
  ),
  Service(
    title: 'Commercial Cleaning',
    description:
        'Customized service to maintain a clean and sanitized commercial property.',
    imageAsset: 'assets/commercial_cleaning.jpg',
  ),
  Service(
    title: 'Pest Control Service',
    description:
        'Eliminate and prevent pest infestations in homes and businesses with tailored treatment plans.',
    imageAsset: 'assets/pest_control.jpg',
  ),
  Service(
    title: '5-in-1 Upholstery Cleaning',
    description:
        'Deep cleans your most-used furniture, removing dirt, allergens, and hidden grime.',
    imageAsset: 'assets/upholstery_cleaning.jpg',
  ),
  Service(
    title: 'Carpet Cleaning',
    description:
        'Lifts deep-seated dirt, stains, and allergens to restore your carpet’s freshness and appearance.',
    imageAsset: 'assets/carpet_cleaning.png',
  ),
  Service(
    title: 'Steam & Vacuum Cleaning',
    description:
        'Sanitizes and loosens dirt using high-temperature steam, plus hydrovacuum for hygienically clean space.',
    imageAsset: 'assets/steam_vacuum.jpg',
  ),
  Service(
    title: 'Duo Disinfection',
    description:
        'Advanced misting and fogging to thoroughly disinfect homes and commercial spaces.',
    imageAsset: 'assets/duo_disinfection.jpg',
  ),
  Service(
    title: 'Zero-Germ Technology',
    description: 'Three advanced disinfection processes for total protection.',
    imageAsset: 'assets/zero_germ.jpg',
  ),
  Service(
    title: 'Floor Polishing Service',
    description:
        'Restores shine and smoothness to your floors, enhancing durability and giving a polished look.',
    imageAsset: 'assets/floor_polishing.png',
  ),
  Service(
    title: 'Aircon Cleaning',
    description:
        'Ensures your unit operates efficiently and circulates clean air.',
    imageAsset: 'assets/aircon_cleaning.jpg',
  ),
  Service(
    title: 'Car Cleaning',
    description:
        'Expert interior and exterior cleaning for your car, convenient and thorough.',
    imageAsset: 'assets/car_cleaning.jpg',
  ),
];

class ServicesPage extends StatelessWidget {
  const ServicesPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('CrystalClean Services'),
        backgroundColor: Colors.teal,
        elevation: 2,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(24)),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFe0f7fa), Colors.white],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Column(
          children: [
            // Header Section
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Professional Cleaning Services',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.teal.shade700,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Choose from our comprehensive range of cleaning solutions',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.grey.shade600,
                    ),
                  ),
                ],
              ),
            ),

            // Services Grid
            Expanded(
              child: MasonryGridView.count(
                crossAxisCount: 2,
                mainAxisSpacing: 16.0,
                crossAxisSpacing: 16.0,
                itemCount: services.length,
                padding: const EdgeInsets.fromLTRB(24.0, 0, 24.0, 24.0),
                itemBuilder: (context, index) {
                  final service = services[index];
                  return _ServiceCard(service: service);
                },
              ),
            ),

            // Call to Action
            Container(
              margin: const EdgeInsets.all(24),
              child: ElevatedButton(
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: const Text(
                          'Booking requested! We\'ll contact you soon.'),
                      backgroundColor: Colors.teal,
                      behavior: SnackBarBehavior.floating,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.teal,
                  foregroundColor: Colors.white,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                  elevation: 4,
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: const [
                    Icon(Icons.phone, size: 20),
                    SizedBox(width: 8),
                    Text(
                      'Book a Service',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ServiceCard extends StatelessWidget {
  final Service service;

  const _ServiceCard({Key? key, required this.service}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 8,
      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: InkWell(
        onTap: () {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('${service.title} selected!'),
              backgroundColor: Colors.teal,
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          );
        },
        borderRadius: BorderRadius.circular(18),
        child: Padding(
          padding: const EdgeInsets.all(18.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: Image.asset(
                  service.imageAsset,
                  height: 120,
                  width: double.infinity,
                  fit: BoxFit.cover,
                  errorBuilder: (BuildContext context, Object error,
                      StackTrace? stackTrace) {
                    return Container(
                      height: 120,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: Colors.teal.shade100,
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: const Icon(
                        Icons.cleaning_services,
                        color: Colors.teal,
                        size: 40,
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 12),
              Text(
                service.title,
                style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                  color: Colors.teal.shade700,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 8),
              Text(
                service.description,
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey.shade600,
                  height: 1.3,
                ),
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 12),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.teal.shade50,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.teal.shade200),
                ),
                child: Text(
                  'Learn More',
                  style: TextStyle(
                    color: Colors.teal.shade700,
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
