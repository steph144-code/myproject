import 'package:flutter/material.dart';

class ContactPage extends StatelessWidget {
  const ContactPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Contact Us'),
        backgroundColor: Colors.teal,
        elevation: 2,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(24)),
        ),
      ),
      body: Container(
        color: Color(0xFF8fd3db),
        child: SingleChildScrollView(
          child: Center(
            child: Padding(
              padding:
                  const EdgeInsets.symmetric(vertical: 40.0, horizontal: 16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(16),
                    child: Image.asset(
                      'assets/contact_banner.png',
                      height: 180,
                      width: double.infinity,
                      fit: BoxFit.cover,
                    ),
                  ),
                  SizedBox(height: 32),
                  Container(
                    padding: EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.9),
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black12,
                          blurRadius: 12,
                          offset: Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Contact Information',
                            style: TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                                color: Colors.teal)),
                        SizedBox(height: 18),
                        Row(
                          children: [
                            Icon(Icons.email, color: Colors.teal, size: 28),
                            SizedBox(width: 10),
                            Text('info@crystalcleanservices.com',
                                style: TextStyle(
                                    color: Colors.black87, fontSize: 16)),
                          ],
                        ),
                        SizedBox(height: 14),
                        Row(
                          children: [
                            Icon(Icons.phone, color: Colors.teal, size: 28),
                            SizedBox(width: 10),
                            Text('(02)-8716-9202 (Landline)',
                                style: TextStyle(
                                    color: Colors.black87, fontSize: 16)),
                          ],
                        ),
                        SizedBox(height: 14),
                        Row(
                          children: [
                            Icon(Icons.smartphone,
                                color: Colors.teal, size: 28),
                            SizedBox(width: 10),
                            Text('+63 917 883 0077 (Globe)',
                                style: TextStyle(
                                    color: Colors.black87, fontSize: 16)),
                          ],
                        ),
                        SizedBox(height: 14),
                        Row(
                          children: [
                            Icon(Icons.smartphone,
                                color: Colors.teal, size: 28),
                            SizedBox(width: 10),
                            Text('+63917 146 2739 (Globe)',
                                style: TextStyle(
                                    color: Colors.black87, fontSize: 16)),
                          ],
                        ),
                        SizedBox(height: 24),
                        Text('Follow us on:',
                            style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.teal)),
                        SizedBox(height: 10),
                        Row(
                          children: [
                            Icon(Icons.facebook, color: Colors.teal, size: 32),
                            SizedBox(width: 10),
                            Icon(Icons.camera_alt,
                                color: Colors.teal, size: 32), // Instagram
                            SizedBox(width: 10),
                            Icon(Icons.video_library,
                                color: Colors.teal, size: 32), // YouTube
                            SizedBox(width: 10),
                            Icon(Icons.music_note,
                                color: Colors.teal, size: 32), // TikTok
                          ],
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 24),

                  // Service Hours
                  Card(
                    elevation: 4,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Service Hours',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 18,
                                  color: Colors.teal)),
                          const SizedBox(height: 12),
                          Row(
                            children: [
                              Icon(Icons.schedule,
                                  color: Colors.teal, size: 20),
                              SizedBox(width: 8),
                              Text('Monday - Friday: 8:00 AM - 6:00 PM',
                                  style: TextStyle(
                                      fontSize: 14, color: Colors.black87)),
                            ],
                          ),
                          SizedBox(height: 8),
                          Row(
                            children: [
                              Icon(Icons.schedule,
                                  color: Colors.teal, size: 20),
                              SizedBox(width: 8),
                              Text('Saturday: 9:00 AM - 4:00 PM',
                                  style: TextStyle(
                                      fontSize: 14, color: Colors.black87)),
                            ],
                          ),
                          SizedBox(height: 8),
                          Row(
                            children: [
                              Icon(Icons.schedule,
                                  color: Colors.teal, size: 20),
                              SizedBox(width: 8),
                              Text('Sunday: Emergency services only',
                                  style: TextStyle(
                                      fontSize: 14, color: Colors.black87)),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 16),

                  // Quick Contact Form
                  Card(
                    elevation: 4,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Quick Contact',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 18,
                                  color: Colors.teal)),
                          const SizedBox(height: 12),
                          TextField(
                            decoration: InputDecoration(
                              hintText: 'Your Name',
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                              prefixIcon:
                                  Icon(Icons.person, color: Colors.teal),
                            ),
                          ),
                          const SizedBox(height: 12),
                          TextField(
                            decoration: InputDecoration(
                              hintText: 'Your Email',
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                              prefixIcon: Icon(Icons.email, color: Colors.teal),
                            ),
                          ),
                          const SizedBox(height: 12),
                          TextField(
                            maxLines: 3,
                            decoration: InputDecoration(
                              hintText: 'Your Message',
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                              prefixIcon:
                                  Icon(Icons.message, color: Colors.teal),
                            ),
                          ),
                          const SizedBox(height: 16),
                          SizedBox(
                            width: double.infinity,
                            child: ElevatedButton(
                              onPressed: () {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text(
                                        'Message sent! We\'ll get back to you soon.'),
                                    backgroundColor: Colors.teal,
                                    behavior: SnackBarBehavior.floating,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                  ),
                                );
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.teal,
                                foregroundColor: Colors.white,
                                padding: EdgeInsets.symmetric(vertical: 12),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8),
                                ),
                              ),
                              child: Text(
                                'Send Message',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
