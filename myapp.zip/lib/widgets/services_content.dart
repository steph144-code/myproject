import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

class ServicesContent extends StatelessWidget {
  final bool isCupertino;

  const ServicesContent({Key? key, required this.isCupertino})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Card(
        elevation: 6,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        color: isCupertino ? CupertinoColors.systemGrey6 : Colors.white,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              isCupertino
                  ? Icon(CupertinoIcons.list_bullet,
                      size: 60, color: CupertinoColors.activeBlue)
                  : Icon(Icons.list, size: 60, color: Colors.blue),
              SizedBox(height: 18),
              Text(
                isCupertino
                    ? 'Services Page (Cupertino)'
                    : 'Services Page (Material)',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10),
              Text(
                'Explore our range of professional cleaning services.',
                style: TextStyle(fontSize: 16, color: Colors.grey[700]),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
